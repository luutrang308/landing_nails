<?php

include_once REINA_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/system-info.php';