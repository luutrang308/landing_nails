<div class="qodef-m-action">
	<a itemprop="url" href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="qodef-m-action-link">
		<span class="qodef-m-text">
			<?php esc_html_e( 'View cart & Checkout', 'reina-core' ); ?>
		</span>
		<span class="qodef-m-background"></span>
	</a>
</div>
