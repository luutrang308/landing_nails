<?php

include_once REINA_CORE_PLUGINS_PATH . '/booked/shortcodes/booked-calendar/booked-calendar.php';