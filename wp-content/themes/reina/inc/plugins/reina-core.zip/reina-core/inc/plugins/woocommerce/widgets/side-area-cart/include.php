<?php

include_once REINA_CORE_PLUGINS_PATH . '/woocommerce/widgets/side-area-cart/side-area-cart.php';