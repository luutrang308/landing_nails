<?php if ( ! empty( $tagline ) ) { ?>
	<span class="qodef-woo-product-tagline" <?php qode_framework_inline_style( $tagline_styles ); ?>><?php echo esc_html( $tagline ); ?></span>
<?php } ?>