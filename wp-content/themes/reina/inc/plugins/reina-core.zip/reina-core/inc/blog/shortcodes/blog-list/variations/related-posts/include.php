<?php

include_once REINA_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/related-posts/related-posts.php';