<?php

include_once REINA_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/info-below/info-below.php';