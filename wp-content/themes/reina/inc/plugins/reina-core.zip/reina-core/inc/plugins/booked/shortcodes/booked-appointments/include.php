<?php

include_once REINA_CORE_PLUGINS_PATH . '/booked/shortcodes/booked-appointments/booked-appointments.php';