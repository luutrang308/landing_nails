<?php


include_once REINA_CORE_INC_PATH . '/blog/templates/single/single-post-navigation/helper.php';
include_once REINA_CORE_INC_PATH . '/blog/templates/single/single-post-navigation/dashboard/admin/single-post-navigation-options.php';