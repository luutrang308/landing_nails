<div class="qodef-e-info-item qodef-e-info-social-share">
    <?php
    $params = array (
        'title'  => '',
        'layout' => 'list' ,
    );

    echo ReinaCoreSocialShareShortcode ::call_shortcode ( $params );
    ?>
</div>
