(function ($) {
	"use strict";
	
	qodefCore.shortcodes.reina_core_clients_list = {};
	qodefCore.shortcodes.reina_core_clients_list.qodefSwiper = qodef.qodefSwiper;
})(jQuery);