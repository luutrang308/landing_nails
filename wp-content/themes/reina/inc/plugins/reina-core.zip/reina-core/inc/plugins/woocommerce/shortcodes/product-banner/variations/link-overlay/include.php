<?php

include_once REINA_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-banner/variations/link-overlay/helper.php';