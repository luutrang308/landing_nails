<?php

include_once REINA_CORE_PLUGINS_PATH . '/woocommerce/woocommerce.php';