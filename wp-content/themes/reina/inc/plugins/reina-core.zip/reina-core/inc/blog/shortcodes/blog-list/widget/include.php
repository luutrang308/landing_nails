<?php

include_once REINA_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/blog-list.php';