<?php

include_once REINA_CORE_INC_PATH . '/header/layouts/standard/helper.php';
include_once REINA_CORE_INC_PATH . '/header/layouts/standard/standard-header.php';
include_once REINA_CORE_INC_PATH . '/header/layouts/standard/dashboard/admin/standard-header-options.php';
include_once REINA_CORE_INC_PATH . '/header/layouts/standard/dashboard/meta/standard-header-meta.php';