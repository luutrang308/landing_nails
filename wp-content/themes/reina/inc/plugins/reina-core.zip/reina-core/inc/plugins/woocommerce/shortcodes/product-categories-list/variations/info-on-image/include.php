<?php

include_once REINA_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-categories-list/variations/info-on-image/info-on-image.php';