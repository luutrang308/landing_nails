<?php if ( has_post_thumbnail () ) : ?>

    <?php the_post_thumbnail ( 'full' ); ?>

<?php endif; ?>