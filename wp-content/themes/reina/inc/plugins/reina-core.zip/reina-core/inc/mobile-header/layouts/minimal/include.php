<?php

include_once REINA_CORE_INC_PATH . '/mobile-header/layouts/minimal/helper.php';
include_once REINA_CORE_INC_PATH . '/mobile-header/layouts/minimal/minimal-mobile-header.php';
include_once REINA_CORE_INC_PATH . '/mobile-header/layouts/minimal/dashboard/admin/minimal-mobile-header-options.php';